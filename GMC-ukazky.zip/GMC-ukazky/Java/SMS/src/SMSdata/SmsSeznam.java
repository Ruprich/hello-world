package SMSdata;

import java.util.ArrayList;

import SMSdata.SmsData;

public class SmsSeznam {
	private ArrayList<SmsData> data;
	
	public SmsSeznam(){
		this.data = new ArrayList<SmsData>();
		
	}
	
	public void add(SmsData sms){
		data.add(sms);
	}
	
	public SmsData get(int index){
		return data.get(index);
	}
	
	
	public int size(){
		return data.size();
	}
	

}
