package SMSdata;



public class SmsData {
	 String textZpravy;
	 String telCislo;
	 String kompTextZpravy;
	 int uspZnaky;
	
	
	
	public SmsData(String textZpravy, String telCislo, String kompTextZpravy, int uspZnaky) {
		super();
		this.textZpravy = textZpravy;
		this.telCislo = telCislo;
		this.kompTextZpravy = kompTextZpravy;
		this.uspZnaky = uspZnaky;
		
	}
	
		
	
	public String getTextZpravy() {
		return textZpravy;
	}
	public void setTextZpravy(String textZpravy) {
		this.textZpravy = textZpravy;
	}
	public String getTelCislo() {
		return telCislo;
	}
	public void setTelCislo(String telCislo) {
		this.telCislo = telCislo;
	}
	
	
	
	public String kompZpravy(String textZpravy){
		String t;
		
		int i = 0;
		while (i!=textZpravy.length()) {
			int ind = textZpravy.indexOf(" ", i)+1;
			textZpravy.charAt(ind).toUpperCase();
		}
		
		
		return t;
	}



	public String getKompTextZpravy() {
		return kompTextZpravy;
	}



	public void setKompTextZpravy(String kompTextZpravy) {
		this.kompTextZpravy = kompTextZpravy;
	}



	public int getUspZnaky() {
		return uspZnaky;
	}



	public void setUspZnaky(int uspZnaky) {
		this.uspZnaky = uspZnaky;
	}

}
