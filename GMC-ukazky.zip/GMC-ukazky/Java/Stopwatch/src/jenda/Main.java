package jenda;

import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * Created by Bara on 02.04.2017.
 */
public class Main extends JFrame{
    private JFrame f;
    private JButton b1, b2;
    private JPanel p, p2;
    private long beginTime = 0;
    private long stopTime = 0;
    private boolean running = false;

    public static void main(String[] args) {
            new Main();
    }

    public void begin(){
        this.beginTime = System.currentTimeMillis();
        this.running = true;
    }

    public void stop(){
        this.stopTime = System.currentTimeMillis();
        this.running = false;
    }

    public void calculate(){
        stop();
        long time;
        time = ((stopTime - beginTime)/1000);
        System.out.print(time);
    }

    public Main(){
        JFrame f;
        f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(500,500);
        f.setLocationRelativeTo(null);


        b1 = new JButton("Start");
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                   begin();
            }
        });
        b2 = new JButton("Stop");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        });

        p = new JPanel();
        p2 = new JPanel();

        p.setBackground(Color.green);
        p.add(b1);
        p2.setBackground(Color.red);
        p2.add(b2);
        //System.out.print(System.currentTimeMillis());

        f.add(p, BorderLayout.NORTH);
        f.add(p2, BorderLayout.SOUTH);
        f.setVisible(true);

    }
}
